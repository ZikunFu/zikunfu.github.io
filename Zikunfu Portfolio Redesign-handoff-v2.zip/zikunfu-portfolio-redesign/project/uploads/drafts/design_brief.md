# Design Brief — zikunfu.github.io redesign

Paste this brief (plus the current `index.md` content as the copy source) into Claude
Design / claude.ai to generate a new homepage. The content in `index.md` is the single
source of truth — the design should present it, not rewrite it.

## Who this is for

Personal portfolio/homepage for **Zikun Fu**, MSc Computer Science graduate (Ontario Tech,
2026), job-searching for **ML/NLP engineering, AI automation, and data/backend roles**.
Primary readers: recruiters (10-second skim) and engineering hiring managers (2-minute
read). The page must make three things obvious within one screen:

1. Published NLP researcher — thesis hit 93.2% F1, IEEE IRI 2025 paper.
2. Ships real systems — a grounded LLM analytics assistant measured at 100% grounding /
   0% hallucination, automation pipelines with cost/human-review gates.
3. Where to go next — resume PDF, GitHub, LinkedIn, email.

## Structure (single page, in this order)

1. **Hero**: name, tagline "ML/NLP · AI Automation · Data Systems", 2–3 sentence intro,
   contact/link row (email, LinkedIn, GitHub, resume PDF button). Optional small portrait
   (`assets/img/portrait.jpg`).
2. **Highlights strip**: 4 compact stat cards — 93.2% F1 (thesis) · 100% grounding / 0%
   hallucination (analytics assistant) · ~$0.15/student LLM grading · 3,400+ records
   migrated. Each with a one-line caption.
3. **Projects** (3 cards): Hermes Clinic Analytics (GitHub link), Web Presence Report
   (no link — private client work, "ongoing"), LLM Exam Grading Pipeline (no link).
4. **Research & publications**: thesis paragraph + publication list with DOI link.
5. **Experience timeline**: 3 roles (Research Assistant, Teaching Assistant, GREx PM).
6. **Skills**: grouped tags (ML/NLP, LLM Engineering, Data & Pipelines, Backend/Infra).
7. **Education** + footer with the same contact links.

## Tone & visual direction

- Clean, technical, understated — closer to a well-designed docs page than a marketing
  site. No stock imagery, no emoji, no animated gimmicks.
- Light theme default; dark mode nice-to-have.
- One accent color (current site uses RGB 0,79,144 — a deep blue; keep or refine).
- Typography-driven hierarchy; generous whitespace; readable measure (~70ch).
- Numbers are the design feature: make the verified metrics (93.2%, 100%/0%, $10.34)
  visually prominent — they are real and load-bearing.

## Hard constraints

- Static output deployable on **GitHub Pages** (plain HTML/CSS/minimal JS, or a Jekyll
  layout). No build pipeline heavier than Jekyll; no external JS frameworks.
- Fully responsive; must read well on mobile.
- All copy comes from `index.md` verbatim — especially: the clinic client is only ever
  "a local optometry clinic" (ongoing engagement), and the grading project is described
  by methodology and aggregate cost only (no student data).
- Keep resume PDF path stable: `assets/resume/Resume_ZikunFu.pdf`.
- Accessible: semantic headings, alt text, WCAG AA contrast.
