# Context for Future Agents — Zikun Fu's Digital Footprint

Last updated: 2026-07-02. This folder (`drafts/`) is gitignored — nothing here publishes.
Read this before editing the homepage, resume, LinkedIn copy, or GitHub profile.

## Who / goal

Zikun Fu, MSc Computer Science graduate (Ontario Tech University; thesis defended
April 15, 2026, passed). Job-searching for ML/NLP engineering, AI automation, and
data/backend roles (Oshawa, ON; open to Toronto/Ottawa/remote). All public surfaces
position him as "ML/NLP · AI Automation · Data Systems".

Surfaces: this repo (homepage zikunfu.github.io + resume PDF compiled from
`assets/resume/main.tex` — compile with `pdflatex main.tex` twice, then
`cp main.pdf Resume_ZikunFu.pdf`; only Resume_ZikunFu.pdf is committed),
GitHub profile ZikunFu, LinkedIn linkedin.com/in/zikun-fu.

## Verified ground truth (source in parentheses)

- MSc CS, Jan 2024 – Apr 2026, GPA 4.24/4.3; BSc (Hons) CS Data Science 2019–2023,
  GPA 3.86/4.3 (LinkedIn education; old degree name "Master of Information Science"
  was WRONG — fixed everywhere 2026-07-02).
- Thesis: "Database Entity Recognition using Language Models" (exact title verified at
  https://hdl.handle.net/10155/2082). DB-ER as sequence labeling over {O, Table,
  Column, Value}; open-world T5 80.8% F1; closed-world MiniLM verification 93.2% F1;
  1,000-example human benchmark (Spider/BIRD) + 15,000 synthetic via SQL AST parsing +
  ILP (thesis abstract, Thesis/db-entity-thesis/my/0_abstract.tex).
- Publication: Z. Fu, C. Yang, K. Davoudi, K.Q. Pu, "Database Entity Recognition with
  Data Augmentation and Deep Learning," IEEE IRI 2025, San Jose.
  DOI 10.1109/IRI66576.2025.00071. Plus Ontario Database Day 2024 talk
  (ondbd.ca/talk_2024/talk_32.pdf).
- Employment (LinkedIn experience section = source of truth for titles/dates):
  - Research Assistant, Ontario Tech, May 2026 – present (contract part-time).
  - Teaching Assistant, CSCI4020U Compilers (Kotlin), Jan 2024 – May 2026.
  - GREx Redevelopment Project Manager, Frazer Faculty of Education, Dec 2024 – Apr
    2025; Symfony/Laravel to Dockerized LimeSurvey 6.x + MySQL; deployed
    grex2.eilab.ca. "60+ research groups" verified in
    "/home/zikun/work/GREx Lime Migration Dev Plan (2024-2025).md".
- hermes-clinic-analytics (github.com/ZikunFu/hermes-clinic-analytics): grounded AI
  analytics chatbot; read-only DuckDB, sqlglot SQL allowlist, provenance on every
  answer; 100% grounding / 0% hallucination on oracle-backed harness; 59 unit tests
  (repo README, verified present in the GitHub copy). NOTE: local working tree at
  /home/zikun/work/2026-Summer/hermes-clinic-analytics is AHEAD of GitHub
  (uncommitted README/code/docs) — Zikun to commit/push himself.
- clinic-SEO-report (/home/zikun/work/2026-Summer/clinic-SEO-report): automated web-
  presence audit pipeline; cost gates + human-review gates for health compliance;
  full run under $1 (README).
- AI_Grading_finals (/home/zikun/work/AI_Grading_finals): LLM grading of scanned
  handwritten finals via Claude/OpenRouter; ~70 students, $10.34 total,
  ~$0.15/student (README).
- WIP, NOT portfolio pieces: clinic-website-demo, AI_Grading (midterm version),
  coursegen_demo.

## Unconfirmed claims (ask Zikun before reusing beyond current copy)

- "3,400+ multilingual records" (GREx ETL) — appears only in his old self-written
  resume; kept in current copy but flagged.
- Research Assistant bullets assume the two 2026 clinic projects are the RA work
  product (strongly implied by dbresearch-ontariotech sbsim dependency; not stated
  in any doc).

## Hard constraints (never violate)

1. The clinic client is only ever "a local optometry clinic"; engagement is
   "ongoing", never completed. The REAL client is identifiable inside
   clinic-SEO-report (src/render/build_report.py hard-codes client name/website and
   named competitors; also in prompts/, build_exec_pdf.py, the agent plan, and all
   git history). Therefore clinic-SEO-report must NOT be pushed to GitHub unless
   fully sanitized into a fresh-history copy.
2. No student names/IDs/exam content from AI_Grading* anywhere public. The
   AI_Grading_finals README itself contains real student names in example file
   paths — never quote them. Aggregate methodology/cost numbers only.
3. Thesis/NER research code (2024-ner, db-entity-thesis) stays private. Homepage
   gets text/figures/citations only. No new public repo for it.
4. No invented metrics. Dropped-for-cause claims (do not resurrect): "outperforming
   widely adopted/industry frameworks", "up to 10% performance gain", "outperforms
   human gold labels", "30x synthetic augmentation" (true ratio 1K to 15K = 15x).
5. No emojis in any authored copy (Zikun's explicit preference).
6. Approval gates: archiving repos and pushing homepage/resume changes live require
   Zikun's go-ahead; LinkedIn has NO write API — drafts only, he pastes manually.

## State as of 2026-07-02

- Homepage + resume overhauled and pushed live (commit 9a52a83).
- 14 course repos archived (CSCI3230U-Lab01/03-08, CSCI2020U_GroupProject,
  csci2020u_ZikunFu, CSCI2020U_Assignment1/2, CSCI2010U-Lab01, AI-Asignment-1,
  Asignment2). CSCI3230U-Lab02 skipped (already private).
- Descriptions/topics set: hermes-clinic-analytics, zikunfu.github.io.
- LinkedIn paste-ready copy: drafts/linkedin_draft.md. Design brief for Claude
  Design: drafts/design_brief.md. GitHub plan: drafts/github_cleanup.md.
- Profile pins CANNOT be set via API (GraphQL has no profile-pin mutation) — manual
  list in github_cleanup.md.
- Featured-repo READMEs overhauled and pushed (2026-07-02, via subagents, claims
  grounded in notebook cells/diffs): Embedding-Model-with-Instructions,
  Fuzzy-Matching-with-Text-Embedding-Model (new README + description + topics),
  PEDFE-EmoAnalysis, miners (fork note describing ICL-NER + DPR extensions; emojis
  stripped). Profile README repo ZikunFu/ZikunFu created and live.
- Still manual for Zikun: paste LinkedIn copy, set pins, confirm the 3,400+ figure
  and RA bullets, run design brief through Claude Design, commit/push local
  hermes-clinic-analytics changes, decide on sanitized clinic-SEO-report release.
