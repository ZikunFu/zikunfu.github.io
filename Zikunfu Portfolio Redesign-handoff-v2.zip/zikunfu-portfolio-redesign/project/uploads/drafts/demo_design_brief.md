# Design Brief — Interactive Project Demos for zikunfu.github.io

For Claude Design. Three small interactive showcase demos that sit inside the Projects
section of Zikun Fu's homepage (or on a dedicated `/demos` page). All three are
**recorded-data replays** — no live LLMs, no live databases, no backend. Each is driven
by a static JSON fixture and a shared stepper/reveal component. Everything must deploy on
GitHub Pages with zero server.

## The shared primitive (build once, feed three fixtures)

One reusable component does the work for all three demos:

- **Fixture loader**: fetches a small local JSON file (see `drafts/demo_fixtures/*.json`,
  to be moved into the site's assets on build).
- **Stepper / reveal**: advances through an ordered set of stages with a manual
  "next"/"run" control and a visible progress indicator, so a hiring manager can pause on
  any stage (especially the SQL). Staggered reveal (~150–300 ms between fields) to convey
  a pipeline, but never auto-advancing past a stage the user hasn't triggered.
- **Card chrome**: title, one-line "what this proves" caption, a "recorded demo · no live
  system" label, and a link to the repo where one exists.

Three fixtures, one widget. Do not build three bespoke widgets.

## Global visual & tech constraints

- Static HTML/CSS/JS only; no external JS frameworks, no CDN calls (matches the main-site
  brief). Vanilla JS or a tiny inline helper is fine. Must work as a Jekyll include or a
  standalone page.
- Reuse the homepage design system: same accent (deep blue ~RGB 0,79,144), typography,
  spacing, light-theme-first with optional dark mode. The demos should look native to the
  page, not like embedded third-party widgets.
- Fully responsive; each demo must be legible and operable on mobile (stack the two-pane
  layouts vertically).
- Accessible: keyboard-operable stepper, semantic headings, alt text, WCAG AA contrast,
  `prefers-reduced-motion` disables the stagger.
- No emojis anywhere.
- Every demo carries a visible "recorded / simulated data" label so nothing reads as a
  live claim.

---

## Demo 1 — Hermes Clinic Analytics: "Grounded query trace"

**Fixture**: `demo_fixtures/hermes.json`

**Concept**: one business question flowing through four real stages —
question -> allowlisted SQL -> executed result -> cited answer — so the displayed number
is visibly derived from the query, not typed by a model.

**Layout**: a question chip / small dropdown (3–4 preset questions) + a "Run" button. On
run, four stages reveal in sequence:
1. **Question** (the plain-English ask).
2. **Generated SQL** — show the `generated_sql` in a monospace block with a
   `gate_verdict: pass` badge. This is the stage to let the user linger on.
3. **Result rows** — render `result_rows` as a compact table.
4. **Grounded answer** — the narration, with a "Source query · N rows" provenance chip
   that expands to show the exact SQL again (the receipt).

**Must include the blocked example.** Add a "try a disallowed query" chip that plays
`blocked_example`: SQL stage shows a `gate_verdict: blocked` badge and the real
`rejection_reason`. The rejection is the single strongest safety proof — make it
prominent, not a footnote.

**Scores strip**: static text from the fixture meta — grounding 100%, hallucination 0%,
0 answer-key leaks — labeled as an oracle-harness result.

**Scope boundaries**: no live LLM, no live DB, no in-browser SQL execution (rows are
recorded). Fixed question set only — **do not add a free-text input** (an open box invites
questions with no canned answer and breaks the grounded illusion). Data is the simulated
sbsim clinic; label it simulated.

**Success criterion**: in 15 s a recruiter believes "the answer's number came out of a
validated SQL query I can read — this system structurally can't hallucinate a figure."

---

## Demo 2 — LLM Exam Grading Pipeline: "Scan -> graded output"

**Fixture**: `demo_fixtures/grading.json`

**Concept**: a handwritten answer scan on the left; on the right, the pipeline's structured
output — per-sub-question score, confidence, legibility, and a human-review flag when
confidence is low. Payoff line: **$0.15/student**.

**Layout**: two panes (stack on mobile). Left = the scan image. Right = output fields that
populate on a "Grade" click, staggered. Show `subscores[]` (score/max, confidence,
legibility) and the `rationale`. Include the model-solution/rubric for the question
(`question.subquestions[].model_solution`) behind a "why this score" expander so the
reasoning is authentic.

**The trust-builder is the flag.** Add a toggle between the two fixture cases:
`high_confidence` and `flagged_low_confidence`. In the flagged case, render a clear
"flagged for human review" state with the `flag_reason` — the flag -> human handoff is the
point, so make it visually distinct (amber state, not an error).

**Cost**: show the aggregate `$10.34 / 70 students / $0.15 each` as static text; do not
compute anything client-side.

**Scope boundaries**: no live Claude/OpenRouter calls (outputs recorded). **No upload
field.** Do not recompute cost.

**Scan image**: `demo_fixtures/grading_scan.png` — the real handwritten Q3 answer page,
already cropped to the answer region only (no name, student ID, or page header) and
stripped of metadata. It corresponds to the `high_confidence` case (Q3.1 two parse trees,
Q3.2 grammar rewrite). Use it as the left-pane scan for that case. For the
`flagged_low_confidence` case, either reuse the same scan (the flag state is what's being
demonstrated) or show a partial/blurred variant — do not source a second real student
page. Ship only this cropped image; no page containing identifying marks.

**Success criterion**: in 15 s a recruiter believes "this turns handwritten exams into
auditable scores for pennies, and it knows when to defer to a human."

---

## Demo 3 — Web Presence Report: "Report snapshot with gates"

**Fixture**: `demo_fixtures/report.json` (fully anonymized — fictional clinic, synthetic
metrics)

**Concept**: a miniature, scrollable version of one anonymized report — the graded
scorecard (GBP, reviews, PageSpeed, geo-grid rank, backlinks, on-page health) plus the
30/60/90 action plan — with the two governance gates made visible.

**Layout**: a scrollable report "page". Render `scorecard[]` as graded section rows
(letter grade chips A–F, colour-coded), a small geo-grid visual for the SoLV/ARP figures,
and the `action_plan` 30/60/90 columns. This is the lightest demo — mostly a styled static
view with one interaction.

**Make the gates visible** as callout chips:
- a "cost approved: $0.72 (< $1.00)" stamp shown before/above the report;
- a "pending clinician sign-off" tag on the flagged clinical claim
  (`gates.clinical_claim_flag`).

Optional single interaction: a before -> after toggle showing a low section grade -> the
projected grade after the action plan.

**Scope boundaries (hard rules):** no real client identity, metrics, reviews, competitors,
or locations — the fixture is a fictional clinic with synthetic values, and the card copy
still reads "a local optometry clinic (ongoing)." No live PageSpeed/GBP/API calls. **No
verbatim review text, ever.** **Do not build a "generate report" button** — this is
private client work; the demo is a viewer, not a tool.

**Success criterion**: in 15 s a recruiter/client believes "he productizes messy
online-presence data into a graded, actionable report — with cost and compliance controls
built in, not bolted on."

---

## Handoff notes

- Fixtures live in `drafts/demo_fixtures/` (gitignored so they don't publish prematurely).
  On build, move them into the site's committed assets (e.g. `assets/demos/`) and point the
  loader there.
- Each fixture is self-describing via its `meta` block (dataset provenance, "simulated" /
  "anonymized" labels, source of the numbers). Surface those labels in the UI.
- If Claude Design prefers a different fixture schema, keep the field semantics — the
  values are real/verified (Demo 1) or PII-safe-by-construction (Demos 2 & 3) and must not
  be re-invented.
